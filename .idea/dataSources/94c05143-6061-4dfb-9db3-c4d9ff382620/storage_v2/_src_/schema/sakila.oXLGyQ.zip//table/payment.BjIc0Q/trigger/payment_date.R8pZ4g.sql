create definer = root@`127.0.0.1` trigger payment_date
    before insert
    on payment
    for each row
    SET NEW.payment_date = NOW();

