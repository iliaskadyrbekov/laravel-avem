create definer = `mysql.sys`@localhost view schema_object_overview as
select `routines`.`ROUTINE_SCHEMA` AS `db`, `routines`.`ROUTINE_TYPE` AS `object_type`, count(0) AS `count`
from `information_schema`.`ROUTINES`
group by `routines`.`ROUTINE_SCHEMA`, `routines`.`ROUTINE_TYPE`
union
select `tables`.`TABLE_SCHEMA` AS `TABLE_SCHEMA`, `tables`.`TABLE_TYPE` AS `TABLE_TYPE`, count(0) AS `COUNT(*)`
from `information_schema`.`TABLES`
group by `tables`.`TABLE_SCHEMA`, `tables`.`TABLE_TYPE`
union
select `statistics`.`TABLE_SCHEMA`                       AS `TABLE_SCHEMA`,
       concat('INDEX (', `statistics`.`INDEX_TYPE`, ')') AS `CONCAT('INDEX (', INDEX_TYPE, ')')`,
       count(0)                                          AS `COUNT(*)`
from `information_schema`.`STATISTICS`
group by `statistics`.`TABLE_SCHEMA`, `statistics`.`INDEX_TYPE`
union
select `triggers`.`TRIGGER_SCHEMA` AS `TRIGGER_SCHEMA`, 'TRIGGER' AS `TRIGGER`, count(0) AS `COUNT(*)`
from `information_schema`.`TRIGGERS`
group by `triggers`.`TRIGGER_SCHEMA`
union
select `events`.`EVENT_SCHEMA` AS `EVENT_SCHEMA`, 'EVENT' AS `EVENT`, count(0) AS `COUNT(*)`
from `information_schema`.`EVENTS`
group by `events`.`EVENT_SCHEMA`
order by `db`, `object_type`;

