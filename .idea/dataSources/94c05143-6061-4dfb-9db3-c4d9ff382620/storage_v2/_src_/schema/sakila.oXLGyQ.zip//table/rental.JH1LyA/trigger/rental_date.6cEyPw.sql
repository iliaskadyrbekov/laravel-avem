create definer = root@`127.0.0.1` trigger rental_date
    before insert
    on rental
    for each row
    SET NEW.rental_date = NOW();

